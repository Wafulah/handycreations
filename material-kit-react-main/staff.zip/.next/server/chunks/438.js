"use strict";
exports.id = 438;
exports.ids = [438];
exports.modules = {

/***/ 2540:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "T": () => (/* binding */ Logo)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8442);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_1__);


const Logo = ()=>{
    const theme = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_1__.useTheme)();
    const fillColor = theme.palette.primary.main;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
        fill: "none",
        height: "100%",
        viewBox: "0 0 24 24",
        width: "100%",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                opacity: 0.16,
                className: "st0",
                d: "M2.78,0h37.54c0.77,0,1.46,0.32,1.96,0.83c0.5,0.51,0.82,1.21,0.82,1.99v33.97c0,0.77-0.31,1.48-0.82,1.99 c-0.5,0.51-1.2,0.83-1.96,0.83H2.78c-0.76,0-1.46-0.32-1.96-0.83C0.31,38.26,0,37.56,0,36.79V2.81c0-0.77,0.31-1.48,0.82-1.99 C1.32,0.32,2.02,0,2.78,0 M40.32,1.62H2.78c-0.32,0-0.62,0.14-0.83,0.35C1.73,2.19,1.6,2.49,1.6,2.81v33.97 c0,0.33,0.13,0.63,0.35,0.84c0.21,0.22,0.51,0.35,0.83,0.35h37.54c0.32,0,0.62-0.13,0.83-0.35c0.21-0.22,0.35-0.52,0.35-0.84V2.81 c0-0.33-0.13-0.63-0.35-0.84C40.94,1.75,40.64,1.62,40.32,1.62"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                className: "st0",
                d: "M3.97,3.64h6.69c-0.34,0.88-0.53,1.8-0.53,2.71v17.91c0,0.3,0.44,0.74,0.73,0.74h1.33 c0.72,0,1.72-0.48,2.3-0.61c-0.47,0.71-2.36,2.33-3.64,3.66l-1.73,0.68c0.17,2.73-1.01,2.75-2.56,5.6l0.08,0.07l3.2-3.52 c-0.01-0.03-0.02-0.07-0.02-0.11c0-0.16,0.13-0.29,0.28-0.29c0.15,0,0.28,0.13,0.28,0.29c0,0.16-0.13,0.29-0.28,0.29 c-0.03,0-0.06,0-0.09-0.01l-3.2,3.51l0.09,0.08c2.34-1.4,2.47-2.75,5.52-2.39l0.8-2.27c1.12-1.14,2.31-2.59,2.96-3.02 c-0.29,1.09-0.73,1.78-0.73,3.31c0,0.59,0.34,1.1,0.97,1.1h22.42c0.09,0,0.18,0,0.27,0v4.59H3.97V3.64z M13.07,3.64h21.94L30.64,8.1 c-1.07-0.74-2.7-1.5-4.39-1.5h-0.24c-4.31,0-7.54,2.92-8.53,6.33c-0.63,2.17-0.14,4.53-0.97,6.5c-0.57,1.34-2.45,3.2-4.2,3.24V6.47 C12.31,5.49,12.61,4.51,13.07,3.64 M39.12,3.69v25.48h-0.03H17.88c0-1.98,1.85-3.5,3.23-4.21c2.13-1.1,4.37-0.16,6.66-0.74 c3.36-0.86,6.84-3.91,6.84-7.92v-1.59c0-1.81-1.08-3.55-1.79-4.63L39.12,3.69z M18.61,20.21L29.03,9.66 c-0.79-0.42-1.94-0.86-3.15-0.86c-2.6,0-4.86,1.7-5.78,3.47c-0.53,1.03-0.89,2.25-0.89,3.76c0,0.89,0.01,1.49-0.1,2.22 C18.98,19.04,18.65,19.71,18.61,20.21 M20.16,22.88c1.52-0.32,1.7-0.71,3.91-0.71c1.66,0,3.09,0.07,4.28-0.45 c1.75-0.76,4.08-3,4.08-5.31v-1.72c0-0.84-0.73-2.59-1.24-2.97L20.16,22.88z"
            })
        ]
    });
};


/***/ }),

/***/ 2662:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "a": () => (/* binding */ useAuth)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var src_contexts_auth_context__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(249);


const useAuth = ()=>(0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(src_contexts_auth_context__WEBPACK_IMPORTED_MODULE_1__/* .AuthContext */ .Vo);


/***/ })

};
;